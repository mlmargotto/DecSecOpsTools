---
layout: post
title: InfosecConsultCon
excerpt: "VALUABLE RESOURCES AND STRATEGIES REVEALED BY THE TOP INFOSEC
CONSULTING ENTREPRENEURSHIP EXPERTS IN THE WORLD"
modified: 2021-01-04
tags: [Consulting]
comments: false
category: blog
---

# VALUABLE RESOURCES AND STRATEGIES REVEALED BY THE TOP INFOSEC CONSULTING
ENTREPRENEURSHIP EXPERTS IN THE WORLD

Ted Demopoulos, author of the popular go to book Infosec Rockstar, has put
together a [FREE online event](http://bit.ly/InfoSecConsultCon) that brings
together the best Infosec consulting and entrepreneurship experts in the
industry to teach you how to become a successful consultant and entrepreneur.

This virtual summit runs from Jan 11-15, but sign up has already started! This
is a rare opportunity to hear notable InfoSec greats share their inside secrets
to their consulting businesses.

Featured speakers include Dr. Eric Cole, Jake Williams, and Ed Skoudis. My
friend Ted also interviewed me, and my session is on Friday, Jan 15. I share
some of my experiences that landed me in full time consulting and lessons that
I learned along the way.

**Share this post!** I hope to see you there. Let me know if you plan to check
it out!! **#InfosecConsultCon**
